package Week5;

public class P5dot1 {
    public static void main(String[] args) {
        System.out.println("\nUse a loop to calculate Pounds per Kilogram \n");
        System.out.println("(1 kilogram = 2.2 pounds)\n  Results Shown Below. \n");

        System.out.format("Kilograms %10s%n", "Pounds");
        System.out.format("--------- %10s%n", "------");
        final double POUNDS = 2.2;
        for( int i = 1; i <= 15; i+=2){
            for(; i <= 3; i+=2){
                double result = i * POUNDS;
                System.out.format("   %d %13.1f%n", i, result);
            }
            for(; i <= 9; i+=2){
                double result = i * POUNDS;
                System.out.format("   %d %14.1f%n", i, result);
            }
            for(; i <= 15; i+=2){
                double result = i * POUNDS;
                System.out.format("   %d %13.1f%n", i, result);
            }
        }
        System.out.println("\nGoodbye");
    }
}

