package Week5;

public class P5dot2 {
        public static void main(String[] args) {
            System.out.println("\nUse a loop to display a table of all numbers");
            System.out.println("from 100 to 1000 divisible by both 5 and 6.");
            System.out.println("Results are separated by 1 space and 10 per line.\n");

            int i = 100;
            for ( ;i < 1000; i++ ){
                for ( ;i < 400; i++ ){
                    if(i % 5 == 0 && i % 6 == 0)
                    {System.out.print(i + " "); }
                    }
                System.out.println();
                for ( ;i < 700; i++ ){
                    if(i % 5 == 0 && i % 6 == 0)
                    {System.out.print(i + " "); }
                    }
                System.out.println();
                for ( ;i < 1000; i++ ){
                    if(i % 5 == 0 && i % 6 == 0)
                    {System.out.print(i + " "); }
                    }
                System.out.println();
            }
            System.out.println("\nGoodbye.");
        }
    }

